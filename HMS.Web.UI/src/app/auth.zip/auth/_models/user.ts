export class User {
    ID: number;
    Email: string;
    Pwd: string;
    CPassword : string;
    // fullName: string;
    Name: string;
    PhoneNo: string;
    remember : boolean;
    AccountType : string;
}